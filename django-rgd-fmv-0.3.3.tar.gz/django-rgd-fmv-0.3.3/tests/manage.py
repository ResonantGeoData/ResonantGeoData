# This file is a marker for pytest-django, to make Django paths here importable
# https://pytest-django.readthedocs.io/en/latest/managing_python_path.html#automatic-looking-for-of-django-projects
