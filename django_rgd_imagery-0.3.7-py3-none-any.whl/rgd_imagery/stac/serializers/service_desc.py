def get_service_desc(request):
    return {}
