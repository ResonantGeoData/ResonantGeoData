import rgd


def test_rgd_version():
    assert rgd.__version__  # Make sure not None
