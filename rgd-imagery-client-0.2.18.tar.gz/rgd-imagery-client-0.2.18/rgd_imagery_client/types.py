from typing import Literal

PROCESSED_IMAGE_TYPES = Literal[
    'arbitrary',
    'cog',
    'region',
    'resample',
    'mosaic',
]
